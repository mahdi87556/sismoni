
import React from 'react';
import { WhatsAppIcon } from './icons/WhatsAppIcon.tsx';
import { CopyIcon } from './icons/CopyIcon.tsx';

interface PaymentInfoProps {
    cardNumber: string;
    phoneNumber: string;
}

const PaymentInfo: React.FC<PaymentInfoProps> = ({ cardNumber, phoneNumber }) => {
    const formattedPhoneNumber = phoneNumber.startsWith('98') ? `${phoneNumber}` : `98${phoneNumber.startsWith('0') ? phoneNumber.substring(1) : phoneNumber}`;

    const copyToClipboard = () => {
        navigator.clipboard.writeText(cardNumber.replace(/-/g, ''));
        alert('شماره کارت کپی شد!');
    };

    return (
        <div className="relative bg-purple-900/20 backdrop-blur-2xl rounded-3xl p-6 sm:p-8 shadow-2xl shadow-purple-500/20 text-center text-white ring-2 ring-offset-4 ring-offset-[#0D1117] ring-purple-500/70">
            <h3 className="text-2xl font-bold mb-2 drop-shadow-md">شانس خود را امتحان کنید!</h3>
            <p className="text-4xl font-extrabold mb-4 tracking-wider drop-shadow-lg">۳۸۵,۰۰۰ <span className="text-2xl font-normal">تومان</span></p>

            <div className="mt-6">
                <p className="mb-2 font-medium">شماره کارت جهت واریز:</p>
                <div 
                    onClick={copyToClipboard}
                    className="group bg-black/20 backdrop-blur-sm rounded-lg p-4 font-mono text-xl sm:text-2xl tracking-widest cursor-pointer border border-white/20 hover:border-purple-400/50 transition-all flex items-center justify-center gap-4"
                >
                    <span>{cardNumber}</span>
                    <CopyIcon className="w-6 h-6 text-white/70 group-hover:text-white transition-colors" />
                </div>
                <p className="text-xs text-white/80 mt-1">برای کپی کردن شماره، روی آن کلیک کنید</p>
            </div>
            
            <div className="mt-8 border-t border-white/20 pt-6">
                <p className="mb-3 font-medium">جهت اطلاعات بیشتر و ارسال فیش واریزی، در واتساپ پیام دهید:</p>
                <a
                    href={`https://wa.me/${formattedPhoneNumber}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center justify-center gap-3 bg-white text-green-600 font-bold px-6 py-3 rounded-full shadow-lg hover:scale-105 hover:bg-gray-100 transition-all duration-300 text-lg"
                >
                    <WhatsAppIcon />
                    <span>تماس در واتساپ</span>
                </a>
                <p className="mt-4 text-xl font-bold text-teal-300 tracking-wider drop-shadow-[0_0_8px_rgba(45,212,191,0.8)]">
                    {phoneNumber}
                </p>
            </div>
        </div>
    );
}

export default PaymentInfo;