import React from 'react';

export const TrophyIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={`h-8 w-8 ${className}`} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M9 11.25l1.5 1.5-1.5 1.5M12 11.25l1.5 1.5-1.5 1.5M15 11.25l1.5 1.5-1.5 1.5M21 21a2.25 2.25 0 01-2.25 2.25H5.25A2.25 2.25 0 013 21V10.535A2.25 2.25 0 014.118 8.618l2.47-1.482A2.25 2.25 0 019.836 8.5v3.375c0 .621.504 1.125 1.125 1.125h2.09c.621 0 1.125-.504 1.125-1.125V8.5a2.25 2.25 0 012.25-2.25 2.25 2.25 0 012.25 2.25v12.535z" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 6a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0z" />
    </svg>
);
