
import React, { useState, useEffect } from 'react';
import QRCode from 'qrcode';
import { StarIcon } from './icons/StarIcon.tsx';
import { CartIcon } from './icons/CartIcon.tsx';
import { WhatsAppIcon } from './icons/WhatsAppIcon.tsx';

interface ShareCardProps {
    cardNumber: string;
    phoneNumber: string;
}

const ShareCard: React.FC<ShareCardProps> = ({ cardNumber, phoneNumber }) => {
    const whatsappLink = `https://wa.me/98${phoneNumber.startsWith('0') ? phoneNumber.substring(1) : phoneNumber}`;
    const [qrCodeSvg, setQrCodeSvg] = useState<string>('');

    useEffect(() => {
        const generateQrCode = async () => {
            try {
                const svgString = await QRCode.toString(whatsappLink, {
                    type: 'svg',
                    width: 100,
                    margin: 1,
                    color: {
                        dark: '#0D1117',
                        light: '#FFFFFF',
                    },
                    errorCorrectionLevel: 'H'
                });
                setQrCodeSvg(svgString);
            } catch (err) {
                console.error('Failed to generate QR code', err);
            }
        };

        if (phoneNumber) {
            generateQrCode();
        }
    }, [whatsappLink, phoneNumber]);

    return (
        <div 
            id="share-card-container"
            className="absolute -left-[9999px] top-0"
            aria-hidden="true"
        >
            <div 
                className="share-image-content w-[450px] h-[800px] bg-[#0D1117] text-white flex flex-col p-8 rounded-3xl overflow-hidden shadow-2xl relative"
                style={{ fontFamily: "'Vazirmatn', sans-serif" }}
            >
                {/* Background patterns */}
                <div 
                    className="absolute inset-0 -z-10 h-full w-full bg-[#0D1117] bg-[linear-gradient(to_right,#ffffff0a_1px,transparent_1px),linear-gradient(to_bottom,#ffffff0a_1px,transparent_1px)] bg-[size:2rem_2rem]">
                    <div className="absolute inset-0 bg-[radial-gradient(circle_500px_at_50%_20%,#31c48d22,transparent)]"></div>
                    <div className="absolute bottom-0 right-0 -z-10 h-1/2 w-1/2 bg-[radial-gradient(circle_800px_at_100%_100%,#c084fc33,transparent)]"></div>
                </div>

                <div className="relative z-10 flex flex-col h-full">
                    {/* Header */}
                    <div className="text-center">
                        <h1 className="text-3xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-teal-300 via-green-400 to-emerald-500 leading-tight">
                             صاحب یک مغازه کامل شوید!
                        </h1>
                         <p className="mt-4 text-2xl font-bold text-purple-400 drop-shadow-[0_0_12px_rgba(192,132,252,0.7)]">
                             سیسمونی فرشته ها
                         </p>
                    </div>

                    {/* Prize Summary */}
                    <div className="mt-6 border-y-2 border-teal-500/30 py-4">
                        <p className="text-center text-lg text-yellow-300 font-bold">با جوایزی به ارزش بیش از ۵۰۰ میلیون تومان</p>
                        <ul className="mt-4 space-y-2 text-base text-gray-300 pr-4">
                            <li className="flex items-center gap-2"><CartIcon className="w-5 h-5 text-teal-400" /> تمامی اجناس و دکور یک مغازه کامل</li>
                            <li className="flex items-center gap-2"><StarIcon /> کامپیوتر و سیستم حسابداری پیشرفته</li>
                        </ul>
                    </div>

                    {/* Cost */}
                    <div className="text-center mt-6">
                        <p className="text-gray-300 text-lg">فقط با پرداخت</p>
                        <p className="text-5xl font-extrabold text-white my-1">۳۸۵,۰۰۰ <span className="text-3xl font-normal">تومان</span></p>
                    </div>

                    {/* Footer / QR Code Section */}
                    <div className="mt-auto text-center bg-black/30 backdrop-blur-sm rounded-2xl p-4">
                       <p className="font-medium mb-3">اطلاعات بیشتر و ارسال فیش واریزی:</p>
                       <div className="flex items-center justify-center gap-4">
                            <div className="p-2 bg-white rounded-lg">
                                {qrCodeSvg ? (
                                    <div dangerouslySetInnerHTML={{ __html: qrCodeSvg }} />
                                ) : (
                                    <div className="w-[100px] h-[100px] bg-gray-200 rounded animate-pulse"></div>
                                )}
                            </div>
                            <div className="text-right">
                                <p className="text-sm">اسکن کنید یا پیام دهید:</p>
                                <div className="flex items-center gap-2 mt-2">
                                    <WhatsAppIcon />
                                    <span className="text-lg font-bold text-teal-300 tracking-wider">
                                        {phoneNumber}
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ShareCard;
