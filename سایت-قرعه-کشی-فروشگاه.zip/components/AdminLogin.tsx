
import React, { useState } from 'react';

interface AdminLoginProps {
  onLogin: (code: string) => void;
  onClose: () => void;
}

const AdminLogin: React.FC<AdminLoginProps> = ({ onLogin, onClose }) => {
  const [code, setCode] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onLogin(code);
  };

  return (
    <div 
        className="fixed inset-0 bg-black/80 backdrop-blur-lg flex items-center justify-center z-50 p-4 transition-opacity duration-300"
        onClick={onClose}
    >
      <div 
        className="w-full max-w-sm p-px bg-gradient-to-br from-teal-400/50 to-transparent rounded-3xl"
        onClick={e => e.stopPropagation()}
      >
        <div className="bg-gray-900/80 backdrop-blur-xl rounded-[23px] p-8 shadow-2xl shadow-teal-900/50">
          <h2 className="text-2xl font-bold text-center text-teal-400 mb-6 drop-shadow-[0_1px_3px_rgba(49,196,141,0.5)]">ورود مدیر</h2>
          <form onSubmit={handleSubmit}>
            <div className="mb-6">
              <label htmlFor="adminCode" className="block mb-2 text-sm font-medium text-gray-300">
                کد ورود
              </label>
              <input
                type="password"
                id="adminCode"
                value={code}
                onChange={(e) => setCode(e.target.value)}
                className="bg-white/5 border border-white/20 text-white text-lg rounded-lg focus:ring-2 focus:ring-teal-400 focus:border-teal-500 block w-full p-3 transition-all duration-300 placeholder-gray-500"
                placeholder="••••••••••"
                required
                autoFocus
              />
            </div>
            <button
              type="submit"
              className="w-full text-white bg-gradient-to-r from-teal-500 to-green-600 hover:from-teal-600 hover:to-green-700 focus:ring-4 focus:outline-none focus:ring-teal-300/50 font-medium rounded-lg text-md px-5 py-3 text-center transition-all duration-300 shadow-lg shadow-teal-500/20 hover:shadow-teal-500/40"
            >
              ورود
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default AdminLogin;