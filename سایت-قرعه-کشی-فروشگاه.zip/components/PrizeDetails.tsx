import React from 'react';
import { StarIcon } from './icons/StarIcon.tsx'; 

interface PrizeDetailsProps {
    onScrollToProducts: () => void;
}

const PrizeItem: React.FC<{ children: React.ReactNode; icon?: React.ReactNode }> = ({ children, icon }) => (
    <li className="flex items-start gap-4">
        <div className="w-6 h-6 text-teal-400 mt-1 flex-shrink-0 drop-shadow-[0_0_5px_rgba(49,196,141,0.7)]">
            {icon || <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>}
        </div>
        <span className="text-gray-300 text-md sm:text-lg">{children}</span>
    </li>
);

const PrizeDetails: React.FC<PrizeDetailsProps> = ({ onScrollToProducts }) => {
    return (
        <div className="mb-8 p-px bg-gradient-to-br from-teal-400/50 via-transparent to-transparent rounded-3xl">
            <div className="bg-gray-900/80 backdrop-blur-2xl rounded-[23px] p-6 sm:p-8 shadow-2xl shadow-teal-900/50">
                <h3 className="text-xl font-bold text-white mb-4">در این قرعه کشی شگفت‌انگیز، شما برنده موارد زیر خواهید شد:</h3>
                <ul className="space-y-4 mb-6">
                    <PrizeItem>
                        تمامی{' '}
                        <button onClick={onScrollToProducts} className="font-bold text-yellow-300 underline decoration-dotted underline-offset-4 cursor-pointer hover:text-yellow-200 transition-colors focus:outline-none">
                            اجناس
                        </button>
                        {' '}یک مغازه کامل
                    </PrizeItem>
                    <PrizeItem><span className="font-bold text-yellow-300">دکور، ویترین و قفسه‌های</span> مدرن</PrizeItem>
                    <PrizeItem>میز مدیریت و تابلوی <span className="font-bold text-yellow-300">چلنیوم</span> سردر مغازه</PrizeItem>
                </ul>
                <div className="border-t border-white/10 pt-6">
                    <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
                        و این پایان ماجرا نیست! 
                        <span className="text-yellow-300 inline-block">هدایای ویژه</span>
                        ما:
                    </h3>
                    <ul className="space-y-4">
                        <PrizeItem icon={<StarIcon />}>یک دستگاه <span className="font-bold text-yellow-300">کامپیوتر</span> به ارزش ۲۰ میلیون تومان</PrizeItem>
                        <PrizeItem icon={<StarIcon />}><span className="font-bold text-yellow-300">سیستم حسابداری</span> پیشرفته به ارزش ۵ میلیون تومان</PrizeItem>
                    </ul>
                </div>
            </div>
        </div>
    );
};

export default PrizeDetails;