import React from 'react';
import { CartIcon } from './icons/CartIcon.tsx';

const ProductList: React.FC = () => {
    const products = [
        'انواع اسباب بازی',
        'سیسمونی کودک',
        'محصولات بهداشتی و مراقبتی',
        'لباس نوزاد و لوازم جانبی',
        'لوازم زنانه و اکسسوری',
        'کالسکه و کریر',
        'گهواره و تخت نوزاد',
        'قمقمه، بطری و ظروف غذا',
    ];

    return (
        <div id="product-list" className="mt-12 p-px bg-gradient-to-br from-teal-400/50 via-transparent to-transparent rounded-3xl scroll-mt-8">
            <div className="bg-gray-900/80 backdrop-blur-2xl rounded-[23px] p-6 sm:p-8 shadow-2xl shadow-teal-900/50">
                <h2 className="text-2xl sm:text-3xl font-bold text-center text-teal-400 mb-6 flex items-center justify-center gap-3 drop-shadow-[0_2px_5px_rgba(49,196,141,0.5)]">
                    <CartIcon />
                    بخشی از محصولات فروشگاه
                </h2>
                <ul className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 text-center">
                    {products.map((product, index) => (
                        <li
                            key={index}
                            className="bg-white/5 p-4 rounded-xl flex items-center justify-center transition-all duration-300 hover:bg-white/10 border border-transparent hover:border-teal-500/50 transform hover:-translate-y-1"
                        >
                            <span className="font-medium text-gray-200 text-sm sm:text-base">{product}</span>
                        </li>
                    ))}
                </ul>
            </div>
        </div>
    );
};

export default ProductList;