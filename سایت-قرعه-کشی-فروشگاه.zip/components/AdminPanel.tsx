import React, { useState } from 'react';
import { LogoutIcon } from './icons/LogoutIcon.tsx';
import { CreditCardIcon } from './icons/CreditCardIcon.tsx';
import { PhoneIcon } from './icons/PhoneIcon.tsx';

interface AdminPanelProps {
  onUpdateCardNumber: (cardNumber: string) => void;
  onUpdatePhoneNumber: (phoneNumber: string) => void;
  currentCardNumber: string;
  currentPhoneNumber: string;
  onLogout: () => void;
}

const AdminPanel: React.FC<AdminPanelProps> = ({
  onUpdateCardNumber,
  onUpdatePhoneNumber,
  currentCardNumber,
  currentPhoneNumber,
  onLogout,
}) => {
  const [cardNumber, setCardNumber] = useState(currentCardNumber);
  const [phoneNumber, setPhoneNumber] = useState(currentPhoneNumber);
  const [feedback, setFeedback] = useState('');

  const showFeedback = (message: string) => {
    setFeedback(message);
    setTimeout(() => setFeedback(''), 3000);
  };

  const handleSaveCardNumber = () => {
    onUpdateCardNumber(cardNumber);
    showFeedback('شماره کارت با موفقیت ذخیره شد.');
  };

  const handleSavePhoneNumber = () => {
    onUpdatePhoneNumber(phoneNumber);
    showFeedback('شماره واتساپ با موفقیت ذخیره شد.');
  };

  return (
    <div className="relative p-px bg-gradient-to-br from-teal-400/50 via-transparent to-transparent rounded-3xl">
      <div className="relative bg-gray-900/80 backdrop-blur-2xl rounded-[23px] p-6 sm:p-8 shadow-2xl shadow-teal-900/50">
        <h2 className="text-3xl font-bold text-center text-teal-400 mb-8 drop-shadow-[0_2px_5px_rgba(49,196,141,0.5)]">پنل مدیریت</h2>
        
        <button 
          onClick={onLogout}
          className="absolute top-4 left-4 text-gray-400 hover:text-red-400 transition-colors p-2 rounded-full bg-white/5 hover:bg-red-500/20"
          aria-label="خروج"
        >
          <LogoutIcon />
        </button>

        <div className="space-y-8">
          {/* Edit Card Number */}
          <div className="space-y-3">
              <label htmlFor="cardNumber" className="flex items-center gap-3 text-lg font-medium text-gray-200">
                  <CreditCardIcon />
                  ویرایش شماره کارت
              </label>
              <div className="flex flex-col sm:flex-row gap-3">
                  <input
                    id="cardNumber"
                    type="text"
                    value={cardNumber}
                    onChange={(e) => setCardNumber(e.target.value)}
                    className="flex-grow bg-white/5 border border-white/20 text-white text-base rounded-lg focus:ring-2 focus:ring-blue-400 focus:border-blue-500 block w-full p-3 transition-all placeholder-gray-500"
                    placeholder="شماره کارت ۱۶ رقمی"
                  />
                  <button onClick={handleSaveCardNumber} className="text-white bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 focus:ring-4 focus:outline-none focus:ring-blue-300/50 font-medium rounded-lg text-sm px-6 py-3 transition-all duration-300 shadow-lg shadow-blue-500/20 hover:shadow-blue-500/40">
                    ذخیره
                  </button>
              </div>
          </div>

          {/* Edit Phone Number */}
          <div className="space-y-3">
              <label htmlFor="phoneNumber" className="flex items-center gap-3 text-lg font-medium text-gray-200">
                  <PhoneIcon />
                  ویرایش شماره واتساپ
              </label>
              <div className="flex flex-col sm:flex-row gap-3">
                  <input
                    id="phoneNumber"
                    type="text"
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                    className="flex-grow bg-white/5 border border-white/20 text-white text-base rounded-lg focus:ring-2 focus:ring-blue-400 focus:border-blue-500 block w-full p-3 transition-all placeholder-gray-500"
                    placeholder="مثال: 09999917415"
                  />
                  <button onClick={handleSavePhoneNumber} className="text-white bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 focus:ring-4 focus:outline-none focus:ring-blue-300/50 font-medium rounded-lg text-sm px-6 py-3 transition-all duration-300 shadow-lg shadow-blue-500/20 hover:shadow-blue-500/40">
                    ذخیره
                  </button>
              </div>
          </div>
        </div>
        {feedback && (
          <div className="absolute bottom-4 right-4 bg-green-500/80 text-white text-sm font-semibold py-2 px-4 rounded-lg shadow-lg transition-all animate-pulse">
            {feedback}
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminPanel;