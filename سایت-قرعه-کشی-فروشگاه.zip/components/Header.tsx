
import React from 'react';

const Header: React.FC = () => {
    return (
        <header className="text-center py-8 mb-4">
            <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-teal-300 via-green-400 to-emerald-500 leading-tight drop-shadow-[0_2px_10px_rgba(49,196,141,0.5)]">
                فقط با ۳۸۵ هزار تومان صاحب یک مغازه و کسب و کار شوید!
            </h1>
            <p className="mt-4 text-lg sm:text-xl text-gray-300">
                به ارزش بیش از
                <span className="font-bold text-yellow-300 mx-2 drop-shadow-[0_1px_5px_rgba(252,211,77,0.5)]">۵۰۰ میلیون تومان</span>
            </p>
            <p className="mt-5 text-2xl sm:text-3xl font-bold text-purple-400 drop-shadow-[0_0_12px_rgba(192,132,252,0.7)]">
                سیسمونی فرشته ها
            </p>
        </header>
    );
};

export default Header;