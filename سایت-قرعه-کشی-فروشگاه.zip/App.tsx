import React, { useState, useEffect } from 'react';
import html2canvas from 'html2canvas';
import AdminLogin from './components/AdminLogin.tsx';
import AdminPanel from './components/AdminPanel.tsx';
import Header from './components/Header.tsx';
import PrizeDetails from './components/PrizeDetails.tsx';
import PaymentInfo from './components/PaymentInfo.tsx';
import { LockIcon } from './components/icons/LockIcon.tsx';
import ProductList from './components/ProductList.tsx';
import ShareCard from './components/ShareCard.tsx';
import { ShareIcon } from './components/icons/ShareIcon.tsx';

const ADMIN_CODE = '2421154340';

const App: React.FC = () => {
  const [cardNumber, setCardNumber] = useState<string>('6219-8619-1753-6319');
  const [phoneNumber, setPhoneNumber] = useState<string>('09999917415');
  
  const [isAdmin, setIsAdmin] = useState<boolean>(false);
  const [showAdminLogin, setShowAdminLogin] = useState<boolean>(false);
  const [isGenerating, setIsGenerating] = useState<boolean>(false);

  useEffect(() => {
    try {
      const savedCardNumber = localStorage.getItem('lottery_cardNumber');
      const savedPhoneNumber = localStorage.getItem('lottery_phoneNumber');
      const adminStatus = sessionStorage.getItem('isAdmin');

      if (savedCardNumber) setCardNumber(savedCardNumber);
      if (savedPhoneNumber) setPhoneNumber(savedPhoneNumber);
      if (adminStatus) setIsAdmin(JSON.parse(adminStatus));

    } catch (error) {
      console.error("Failed to load data from storage", error);
    }
  }, []);

  const handleLogin = (code: string) => {
    if (code === ADMIN_CODE) {
      setIsAdmin(true);
      setShowAdminLogin(false);
      sessionStorage.setItem('isAdmin', 'true');
    } else {
      alert('کد وارد شده اشتباه است.');
    }
  };
  
  const handleLogout = () => {
    setIsAdmin(false);
    sessionStorage.removeItem('isAdmin');
  };

  const handleUpdateCardNumber = (newCardNumber: string) => {
    setCardNumber(newCardNumber);
    localStorage.setItem('lottery_cardNumber', newCardNumber);
  };

  const handleUpdatePhoneNumber = (newPhoneNumber: string) => {
    setPhoneNumber(newPhoneNumber);
    localStorage.setItem('lottery_phoneNumber', newPhoneNumber);
  };
  
  const handleScrollToProducts = () => {
    document.getElementById('product-list')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  const downloadImage = (canvas: HTMLCanvasElement) => {
    const link = document.createElement('a');
    link.download = 'قرعه-کشی-سیسمونی-فرشته-ها.png';
    link.href = canvas.toDataURL('image/png', 1.0);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleShare = async () => {
    const elementToCapture = document.getElementById('share-card-container')?.querySelector('.share-image-content');
    if (!elementToCapture || isGenerating) return;

    setIsGenerating(true);
    try {
      const canvas = await html2canvas(elementToCapture as HTMLElement, {
        backgroundColor: '#0D1117',
        useCORS: true,
        scale: 2,
      });

      canvas.toBlob(async (blob) => {
        if (blob && navigator.share && navigator.canShare) {
          const file = new File([blob], 'قرعه-کشی-سیسمونی-فرشته-ها.png', { type: 'image/png' });
          const shareData = {
            files: [file],
            title: 'قرعه کشی رویایی سیسمونی فرشته ها',
            text: 'با ۳۸۵ هزار تومان صاحب یک مغازه کامل با تمام اجناس و دکور شوید!',
          };
          try {
            await navigator.share(shareData);
          } catch (error) {
            if ((error as DOMException).name !== 'AbortError') {
              console.error('Error sharing file:', error);
            }
          }
        } else {
          downloadImage(canvas);
        }
      }, 'image/png');

    } catch (error) {
      console.error('Error generating share image:', error);
      alert('خطا در ایجاد تصویر برای اشتراک گذاری. لطفا دوباره تلاش کنید.');
    } finally {
      setIsGenerating(false);
    }
  };


  return (
    <div className="bg-[#0D1117] min-h-screen text-white antialiased selection:bg-teal-500/80 selection:text-white">
       <ShareCard 
        cardNumber={cardNumber} 
        phoneNumber={phoneNumber}
       />

      <div className="relative isolate min-h-screen overflow-hidden">
        <div 
          className="absolute inset-0 -z-10 h-full w-full bg-[#0D1117] bg-[linear-gradient(to_right,#ffffff0a_1px,transparent_1px),linear-gradient(to_bottom,#ffffff0a_1px,transparent_1px)] bg-[size:2rem_2rem]">
            <div className="absolute inset-0 bg-[radial-gradient(circle_500px_at_50%_200px,#31c48d22,transparent)]"></div>
            <div className="absolute bottom-0 left-0 -z-10 h-1/2 w-1/2 bg-[radial-gradient(circle_800px_at_0%_100%,#1e40af33,transparent)]"></div>
        </div>
        
        <div className="container mx-auto p-4 sm:p-6 md:p-8 max-w-3xl">
          {isAdmin ? (
            <AdminPanel
              onUpdateCardNumber={handleUpdateCardNumber}
              onUpdatePhoneNumber={handleUpdatePhoneNumber}
              currentCardNumber={cardNumber}
              currentPhoneNumber={phoneNumber}
              onLogout={handleLogout}
            />
          ) : (
            <>
              <Header />
              <PrizeDetails onScrollToProducts={handleScrollToProducts} />
              <PaymentInfo cardNumber={cardNumber} phoneNumber={phoneNumber} />
              <ProductList />
            </>
          )}

          {!isAdmin && (
             <>
              <div className="fixed bottom-4 right-4 z-20">
                <button
                  onClick={handleShare}
                  disabled={isGenerating}
                  className="bg-purple-500/20 backdrop-blur-md border border-white/20 text-white p-3 rounded-full shadow-lg transition-all duration-300 hover:bg-purple-500/30 hover:border-white/30 hover:scale-110 focus:outline-none focus:ring-2 focus:ring-purple-400 focus:ring-offset-2 focus:ring-offset-[#0D1117] disabled:opacity-50 disabled:cursor-not-allowed"
                  aria-label="اشتراک‌گذاری"
                >
                  {isGenerating ? (
                    <svg className="animate-spin h-6 w-6 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                  ) : (
                    <ShareIcon />
                  )}
                </button>
              </div>
              <div className="fixed bottom-4 left-4 z-20">
                <button
                  onClick={() => setShowAdminLogin(true)}
                  className="bg-white/10 backdrop-blur-md border border-white/20 text-white p-3 rounded-full shadow-lg transition-all duration-300 hover:bg-white/20 hover:border-white/30 hover:scale-110 focus:outline-none focus:ring-2 focus:ring-teal-400 focus:ring-offset-2 focus:ring-offset-[#0D1117]"
                  aria-label="ورود مدیر"
                >
                  <LockIcon />
                </button>
              </div>
            </>
          )}
        </div>
      </div>

      {showAdminLogin && (
        <AdminLogin onLogin={handleLogin} onClose={() => setShowAdminLogin(false)} />
      )}
    </div>
  );
};

export default App;